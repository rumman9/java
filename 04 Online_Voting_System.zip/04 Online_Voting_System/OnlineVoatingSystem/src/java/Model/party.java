
package Model;


public class party {
  public  String Count;
   public String Name;
}
