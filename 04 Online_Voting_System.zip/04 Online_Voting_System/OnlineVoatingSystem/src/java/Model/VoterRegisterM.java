package Model;

public class VoterRegisterM {

    public String name;
    public String surname;
    public String voter_card_number;
    public String address;
    public String dob;
    public String contact;
    public String email;
}
