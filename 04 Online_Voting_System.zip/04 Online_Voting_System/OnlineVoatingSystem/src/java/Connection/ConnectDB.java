
package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class ConnectDB { 
    public  Connection con = null;
    public  Statement stmt = null;
    public  String Query;

    public ConnectDB() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/voating", "root", "");
            stmt = con.createStatement();
        } catch (Exception e) {
            con = null;
        }
    }
}
