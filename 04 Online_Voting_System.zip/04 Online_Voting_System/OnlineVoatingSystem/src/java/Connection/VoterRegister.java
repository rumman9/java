package Connection;

import Controller.Register;
import Model.VoterRegisterM;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpSession;

public class VoterRegister extends ConnectDB {

    public int VoterRegister(VoterRegisterM aVoterRegisterM) {
        try {
            int count = 0;
            count = stmt.executeUpdate("insert into voter_register(name,surname,voter_card_number,contact,address,dob,email)values('" + aVoterRegisterM.name + "','" + aVoterRegisterM.surname + "','" + aVoterRegisterM.voter_card_number + "','" + aVoterRegisterM.contact + "','" + aVoterRegisterM.address + "','" + aVoterRegisterM.dob + "','" + aVoterRegisterM.email + "')");
            return count;
        } catch (Exception ex) {
            return 0;
        }
    }

    public boolean ISExistVoter(VoterRegisterM aVoterRegisterM) {
        try {
            Query = "SELECT * FROM voter_register where voter_card_number='" + aVoterRegisterM.voter_card_number + "'";
            ResultSet rs = stmt.executeQuery(Query);
            if (rs.next() == true) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }

}
